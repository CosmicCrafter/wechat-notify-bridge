# 通知桥开发接入包

先读 DEPLOYMENT.json 获取实际服务地址（在线下载包提供），然后读 docs/integration/README.md，再读 docs/server/API.md。
接口规范：server/openapi.json；Python 示例：examples/python/notify_bridge.py。
本包不含密钥和服务端安装程序。请让管理员另行提供服务地址和专属客户端 Key。
完整 MCP 插件和服务器源码：https://github.com/CosmicCrafter/wechat-notify-bridge
文档中未包含的部署/插件源码链接请在完整仓库查看。
