# 通知桥接入文档包

先读 [接入指南](docs/integration/README.md)，按用途选择 [AI 安装](docs/integration/CLIENT-SETUP.md) 或 [HTTP 接入](docs/integration/HTTP.md)。
匿名下载只含通用资料，没有实例配置。若管理员提供 DEPLOYMENT.json / CONNECTION.json，使用其中实际 base_url 和 mcp_url，不自行拼接迁移后的 MCP 地址。
版本与公开源指纹见 RELEASE.json；接口规范 server/openapi.json，示例 examples/python/notify_bridge.py。
本包不含真实 Key、MCP 可执行插件或服务端安装程序。请管理员另行提供私有凭据或从向导下载对应接入包。
未收录的维护/源码资料链接会明确指向完整仓库；历史设计和验收记录不混入本包。
