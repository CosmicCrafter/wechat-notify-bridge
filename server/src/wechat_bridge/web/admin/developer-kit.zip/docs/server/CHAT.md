# 手机会话页

入口为配置的 `WECHAT_PUBLIC_BASE_URL` 加 `/chat/`，与 `/admin/` 分开。当前版本请查看服务器 `/health` 响应和插件清单。

手机会话页与管理端分别验证身份：手机 Cookie 不能代替管理员账号会话，应用 Key 也不能登录管理端。管理端使用账号密码，有效管理 Cookie 可在刷新后恢复；首次初始化与忘记密码见[管理与恢复](https://github.com/CosmicCrafter/wechat-notify-bridge/blob/main/docs/product-v3/OPERATIONS.md)。

AI 也可以发送 [任务卡片](TASK-CARDS.md)：在会话中选择一个方案或自行回复，点击“提交决定”。页面会区分已答复与 AI 的处理进度。

## 使用

1. 在已绑定的微信 ClawBot 中发送 `/web`。
2. 打开消息下方的会话链接，输入 8 位登录码。新码替换旧码，10 分钟内有效且只能使用一次。
3. 登录保留 30 天。选择聊天即可查看双向记录；通知中的链接会定位具体消息。
4. 在底部回复框输入正文，点击发送。无需手写路由标签；支持 Markdown，电脑可用 Ctrl/Command+Enter 提交。
5. 页面显示“等待 AI 读取”，客户端调用 MCP `getMessages` 后显示“客户端已读取”。这两个状态都不代表任务已执行。

普通短消息保留正文；超过微信 2000 字符预算时发送短摘录，完整内容保存在会话页（最大 20000 字符）。可向上翻页查看旧消息，也可以从通知定位后查看较新的消息。关闭/停用/删除客户端后保留会话历史，停止接收该会话的新网页回复。

在微信发送 `/logout` 撤销全部手机登录。管理员也可在管理页面生成一次性码、退出全部手机登录。页面上的“退出登录”仅退出当前浏览器。

## 数据与边界

- 只保存经过通知桥的消息。没有自动读取 Codex、GPT 等宿主的全部历史或工具输出。
- 升级时可导入已保存的直接路由微信入站正文；旧版本只保存发送哈希，无法恢复旧出站正文。公共/未知/含糊标签消息保持原公共收件箱，不猜测会话归属。
- 新会话的入站和出站正文使用现有 Fernet 主密钥加密。原来的回执和去重空间保持不变；失败的微信发送也显示正文，但明确提示提醒失败或未确认。
- 管理指令、API 密钥和一次性登录码不进入普通会话时间线或 MCP 收件箱。持久化的会话正文仍可能包含用户主动提交的敏感内容，应保护数据库及加密密钥。
- 网页回复通过同一收件箱交给对应客户端。没有新增轮询唤醒 AI 或宿主任务执行机制。
- 网页操作不属于微信收发，不更新微信 context_token 或 12 小时心跳计时；微信提醒可能因会话状态失败，正文仍可在网页查看。

## 身份验证

手机会话页供唯一的微信主人使用，可以查看各客户端的会话。API 客户端仍受自己的密钥和 conversation_id 约束；API 密钥不能换取手机登录会话。

登录码最多尝试 6 次，哈希保存、使用后失效。浏览器会话使用随机 token，服务器只存哈希，通过 HttpOnly、Secure、SameSite=Strict Cookie 传递，路径限定到公开地址的 `/chat/`。仅本地回环 HTTP 预览关闭 Secure。会话有效期固定 30 天，不因访问续期。

写操作要求同源 Origin 和自定义请求头；真实 HTTPS 域名必须正确配置为 WECHAT_PUBLIC_BASE_URL。页面不把管理密码或 API Key 写入 URL/localStorage。HTML、脚本、表单、外部图片嵌入会被过滤；普通 HTTPS 链接可访问。

## 实现与验证

`server/src/wechat_bridge/services/portal.py` 与 `api/portal.py` 管理会话、登录和历史；`server/src/wechat_bridge/web/chat/` 是独立页面。静态依赖随服务一起部署，不从第三方 CDN 加载。依赖锁定在 `frontend/package-lock.json`，源码与资源哈希位于 `frontend/build-manifest.json`，许可证见 `frontend/THIRD-PARTY-NOTICES.md`。

Markdown 解析使用 [Marked](https://marked.js.org/)，输出由 [DOMPurify](https://github.com/cure53/DOMPurify) 过滤，并额外限制可用标签与链接协议。不要移除过滤步骤或放宽 CSP 以支持任意 HTML。

测试：`python -m pytest -q server/tests mcp-plugin/tests`。`test_portal.py` 覆盖鉴权、CSRF、过期与撤销、加密全文、失败回执、历史迁移、分页定位、路由隔离、重复提交及心跳不受网页影响。真实手机微信中的外链打开和通知展示还需手机实测，桌面手机尺寸模拟不能替代它。
