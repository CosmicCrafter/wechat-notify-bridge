# 飞书双向通道

新增机器人请先看 [新增飞书 Bot 操作指南](https://github.com/CosmicCrafter/wechat-notify-bridge/blob/main/docs/server/%E6%96%B0%E5%A2%9E%E9%A3%9E%E4%B9%A6Bot%E6%93%8D%E4%BD%9C%E6%8C%87%E5%8D%97.md)，包含后台逐步配置、发布和实机验收。

服务器 1.15.0 与插件 1.9.0 开始支持可选飞书应用机器人。与微信共用客户端密钥、会话、历史、任务状态和唤醒事件；不需要绑定微信，也不会改变微信上下文、推送计数或心跳。普通程序可直接调用相同 HTTP API。

第一阶段使用现有 HTTPS 服务接收飞书事件与卡片回调。飞书默认关闭，无额外接收进程，不增加 SDK 或前端框架。现有 Key 默认关联原微信 Bot，旧调用保持兼容。每个 Bot 绑定一个本人收件身份，当前不开放群聊、多租户和飞书图片/文件收件；长连接接收可在通道边界内后续加入。

## 配置应用

1. 在[飞书开发者后台](https://open.feishu.cn/app)创建企业自建应用，启用机器人能力。群自定义 Webhook 机器人不具备本项目需要的原生卡片回传能力。
2. 申请以应用身份发消息 `im:message:send_as_bot`、读取用户发给机器人的单聊消息 `im:message.p2p_msg:readonly`，设置应用可用范围包含本人并发布。
3. 在通知桥 Admin 的“通信连接”添加飞书 Bot，从原记录继续配置，填写 App ID、App Secret、本人 Open ID、Verification Token 和 Encrypt Key，勾选启用。Open ID 在该应用上下文中获取，不能使用其他应用的 Open ID。
4. 事件配置与回调配置都选择“发送至开发者服务器”，填写管理页为这个 Bot 显示的同一个地址：`https://你的域名/bridge/channels/feishu/<bot_id>/callback`。两处配置与 Admin 使用相同 Verification Token / Encrypt Key；接收端只接受加密并通过签名校验的事件。
5. 订阅消息事件 `im.message.receive_v1` 和卡片回调 `card.action.trigger`，发布新版本，使权限与订阅生效。
6. 给机器人发送带有会话标签的消息，或引用发出的通知回复，确认 AI 的收件箱出现 `source="feishu"`。有宿主接收器或事件订阅时会沿现有机制唤醒；安装插件本身不会启用唤醒。

App Secret 和回调密钥加密存入已有 SQLite 数据库，不写进源码、插件、镜像或普通日志，管理员鉴权后的配置页会回显，公共状态接口不返回这些凭据；不要将配置页截图或完整接口响应公开。空白密码字段保留原值；应用与配对用户身份固定，Secret 和回调密钥可以轮换。停用飞书保留历史，微信继续正常运行。备份规则与原服务一致：数据库和加密主密钥一起备份。

## 调用

在 Admin 为程序或 AI 创建独立客户端密钥，关联允许使用的 Bot，登记当前聊天并保存 `conversation_id`。同一客户端可以授权微信、飞书 A、飞书 B 等多个 Bot，每次明确选择一个 Bot。

```json
{
  "bot_id": "该飞书Bot的ID",
  "conversation_id": "已登记的会话ID",
  "dedup_key": "system-error-unique-event",
  "text": "**运行异常**\n\n数据同步失败，请检查任务日志。"
}
```

在“接入应用”的 Bot 权限中勾选此 Bot，然后向 `/api/messages` POST 上面的 JSON，带 `Authorization: Bearer <客户端密钥>`。`/api/notifications`、`/api/task-cards` 与 MCP 发送工具同样接受 `bot_id`，详见[多 Bot 规则](BOTS.md)。

回执查询 `/api/deliveries` 或 `getDeliveryStatus` 要带原 `bot_id`、会话和事件键。不同 Bot 的同名事件键独立；发送结果不明时不得切换 Bot 或换键重发。超时保留未知状态，重复请求只返回原记录。`api_accepted` 仅表示飞书接口接受，不表示本人已查看或手机已收件。

## 回复与任务卡片

普通回复可在飞书引用该会话的通知，自动按上游消息 ID 关联；也可以用 `[客户端-会话] 正文`。不能明确路由的消息进入公共收件箱，不自动唤醒某个 AI。只接收配置的本人单聊，忽略其他用户、群聊及机器人消息。

卡片采用飞书 JSON 2.0，复用已有单选、多选、快捷确认、独立输入和轻量表单定义。回调按配对用户、原消息、任务和会话联合校验，在本地事务中提交；相同答案重复回调只产生一条收件与唤醒事件，冲突答案、过期任务和已关闭/停用会话均不可提交；新 UI 仅归档不关闭通信。答案进入统一 `getMessages`，返回 `task_response`；提交表示已答复，后续执行由调用方决定。

`updateTaskCard` 更新共享任务状态并尝试更新原飞书卡片，返回 `card_delivery`；更新失败不回滚已保存的任务状态，也不自动重新执行任务。手机会话页提交仍使用同一任务状态，旧飞书卡片再点击会重新校验。

机器人支持 `/help`、`/status`、`/list` 与 `/web`。`/web` 返回一次性登录码用于完整会话页；密钥生命周期仍由 Admin 管理。指令重投不重新生成登录码，回复正文暂时加密排队，发送尝试后清除，旧指令不执行。

## 验证与边界

### 点击卡片提示 200671

先检查对应应用的回调配置是否已发布，再检查服务端回调日志。2026-10-12 的真实回调排查发现，卡片请求的 `X-Lark-Request-Timestamp` 使用 Go 日期字符串（含数值时区及可选单调时钟后缀），只接受数字时间戳会错误返回 401。

当前实现支持 Unix 秒、毫秒及上述带时区格式；始终使用未经修改的原始时间戳参与签名计算，并保留 5 分钟有效期、加密 Token 和 App ID 校验。解析失败或验签失败不能通过跳过校验解决。固定阶段诊断日志不包含正文或凭据；只有在签名和应用身份均通过后，未知时间格式才记录该时间字段用于排障。

线上非审批诊断卡已验证 Go 时间格式、签名和处理响应。该诊断不代表真实审批已经执行；实际任务仍须通过原任务状态与业务系统结果核对，不能因客户端报错就重建审批或重复执行。

模拟上游与真实加密签名的 HTTP 测试覆盖发送、独立去重、凭据隔离、本人过滤、引用路由、统一唤醒事件和五种卡片。测试不等于飞书实机验收：部署后还须验证实际消息到达、卡片渲染、提交回调和对应宿主唤醒。

协议参考：[发送消息](https://open.feishu.cn/document/server-docs/im-v1/message/create)、[接收消息](https://open.feishu.cn/document/server-docs/im-v1/message/events/receive)、[卡片回调](https://open.feishu.cn/document/feishu-cards/card-callback-communication)、[表单容器](https://open.feishu.cn/document/feishu-cards/card-components/containers/form-container)。加密和签名实现对照飞书[官方 Python SDK](https://github.com/larksuite/oapi-sdk-python/tree/5a3c9779bc013258203fcadab2660a1b276feb34/lark_oapi)。

### 飞书输入任务：引用目标卡片回复

飞书 `mode=input` 卡片显示问题和引用回复说明，不展示表单输入框。请长按目标卡片选择「回复」后发送文本；无论当前有几个待填任务，都不会猜测裸文本的答复目标。没有明确关联的文字保留待归属，不会自动提交任务；管理员明确归属消息也不等于替用户答题。文本按字符串保存，保留前导零，最多 2000 字。

引用按同一 Bot 的原平台消息 ID 精确关联，未知引用、标签与引用冲突不会改投另一任务。只有可写、未过期的原输入任务可答复；斜杠命令、超过十分钟的延迟消息和重复事件不会产生新答案。新 UI 归档只改变列表可见性，不关闭通信；停用应用或撤销 Bot 授权仍会拒绝答复。

结果仍通过原 `task_response` 和收件接口返回；后台尝试更新原飞书卡片。单选、多选、确认和多字段表单继续使用原生卡片控件，微信流程不变。
