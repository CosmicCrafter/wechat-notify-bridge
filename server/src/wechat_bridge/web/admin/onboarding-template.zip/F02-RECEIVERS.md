# F02 会话接收与恢复

一个应用身份可有多个会话，沿用已有应用 Key。旧会话默认 legacy，继续原接口；只有 protected 会话增加独立会话接收能力。服务验证能力持有，不验证具体 Codex、Claude、ChatGPT 聊天身份。相同用户、共享宿主文件系统中的其他进程可能读到该文件，不能据此宣称宿主强隔离。

## 本机 MCP 操作

维护者在原私有 client.json 中添加 receiver_file 的绝对路径，每个接收上下文使用独立文件；不要指向应用配置本身。管理端创建 protected 会话并保存首条消息后，在“接收绑定与权限”下载配对文件，私下放在该位置。配对 5 分钟有效，兑换后适配器自动挑战验证并保存 24 小时能力，不向模型返回令牌。过期、丢失或换宿主时，由管理员重新配对/换绑；旧能力、订阅与领取资格撤销。

AI 主动 registerConversation(receiver_mode="protected", host_type="codex" 或 "claude") 也必须预先配置独立 receiver_file。首次签发后保存并验证；重复注册不重发秘密或抢占绑定。远程 MCP 无已验证的私有存储能力时拒绝 protected 注册；已有受控能力可通过 X-Notify-Receiver 请求头使用，真实宿主头转发与聊天隔离仍须实际验收。不要将真实能力、配对码、Key 粘贴到模型对话。

主接收者可以收发、领取与报告；观察者只读。无能力、错会话或过期均拒绝，不退回共享应用 Key。metadata 可读不等于消息可读。Key/OAuth、Bot 授权仍逐次检查。

## HTTP、补查与执行

直接 HTTP 程序按以下顺序操作；这是当前实现的操作语义，不是 OpenAPI 已声明的完整成功响应模型：

| 操作 | 请求与观察结果 | 安全要求 |
|---|---|---|
| 主动登记 | POST /api/conversations，conversation_key 稳定、receiver_mode=protected、host_type=http；首次响应有 id 与 receiver_setup | 重复同键只返回会话，不重新给 setup |
| 保存 setup | 在受控进程读取 receiver_setup.receiver_token 与 challenge | 两者进私有存储，不打印完整响应、不进入模型上下文 |
| 验证 | POST /api/receivers/verify；原应用 Bearer 加 X-Notify-Receiver；JSON 的 challenge 使用首次返回值 | 验证成功后删除已用 challenge；仅有应用 Key 不算完成 |
| 复查 | GET /api/conversations/{id}/receiver 检查绑定元数据 | 能读元数据不证明能读消息；观察者不具有写权限 |
| 收件与处理 | GET /api/inbox 明确 conversation_id；领取/续期/报告继续带原应用与本会话能力 | A/B 会话各自保存能力；失败不去头降级，不猜另一会话 |

管理员创建的会话先由配对文件的 pairing_code 调用 /api/receivers/exchange 取得 setup；兑换时不带接收头，之后仍执行验证。HTTP 应用负责自己的私有存储，stdio 包则由既有适配器管理 receiver_file；不要混为一个自动安装步骤。

业务程序从首次受保护注册或管理员配对取得 setup，私有保存并用 /api/receivers/verify 完成 challenge。请求带原应用 Bearer 与 X-Notify-Receiver。保存每会话 inbox 游标；事件回调只提醒，离线后用持久收件补查，不自动启动 AI。

protected 领取默认租约 120 秒，可设 30～900 秒，返回 claim_id/generation/lease_expires。续期用 /api/inbox/{id}/renew；报告带当前 generation。超时接管需新的 request_id，递增代际，旧领取者不能覆盖新结果；过期后重复旧 request_id 返回 inbox_claim_expired。执行端仍需以稳定 inbox_id 幂等处理外部副作用，不能承诺恰好一次。旧 legacy 的 generation=0、lease_expires=null，保留原领取合同，不具有 protected 的租约恢复保证。

## 生命周期与通知

新 UI 归档只改变列表；旧 setConversationActive 仍关闭通信。静音保留正文和任务但抑制普通平台提醒。结束外部监控发出结构化 stop_monitor 命令，执行端真正完成停止后，领取命令并带 stop_id/inbox_id/claim_id/generation 回执；收到匹配回执后才关闭通信和绑定。无回执只显示待确认/超时，授权回执不证明操作系统进程已停止。

应用普通默认 A、会话偏好、获授权 urgent B 按确定规则选择，显式 bot_id/channel 保持原目标。stdio 私有配置 use_notification_policy=true 才停止注入旧默认 Bot；旧默认行为不变。保留原省略目标的请求与去重键查回执。紧急 B 必须飞书、与 A/备用不同，默认间隔 60 秒，可配 30～86400 秒；普通调用不能借 B 绕过授权。飞书 B 不保证突破手机静音。

备用只在发送前确认连接停用或缺配置且未开始适配器投递时，按管理员设置使用一次；不会复制业务任务。显式目标、准备失败或未知发送不自动改投。原目标的准备失败只允许保持完整原参数显式重试；未知结果先查回执，不自动重发。管理端投递记录保留分流依据与每次尝试。

## 迁移与回退

F02 迁移保留旧记录、Key、正文和旧 active=0 停用状态。使用一致性 SQLite backup，配套原加密密钥和匹配代码，在隔离无生产出口环境验证重开、解密、权限和历史。跨越 F02 的旧 1.16 二进制不会执行新接收/撤销策略，不能只切旧代码继续读新库；同结构版本也必须先用最新副本验证兼容后才决定保留新数据回退。正式恢复须有当次授权；先保全升级期间新增记录，不能覆盖旧快照后宣称零丢失。

为什么需要这些步骤、故障时间线及 legacy/protected 的差异，见服务 /docs/ 导航中的“多会话与可靠收件”。具体字段约束见同站“请求字段合同”与公开 OpenAPI；HTTP 接入包也包含该规范，不是在这里维护另一份参数表。

本页维护当前接收契约，不累计各轮测试结果。R2 已验证真实 Codex 主动调用与跨能力拒绝，R1/R3 有真人收发和隔离恢复证据；具体宿主聊天强身份、Claude Code 与 Work/Dot 自动唤醒仍不能据此宣称通过。历史范围见完整仓库 docs/history/release-1.17.0.md；每个新环境仍须实际验收。
